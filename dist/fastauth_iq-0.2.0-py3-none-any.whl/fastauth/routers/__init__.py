from fastauth.routers.auth import AuthRouter

__all__ = ['AuthRouter']
