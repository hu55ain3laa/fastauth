from fastauth.utils.session import get_session

__all__ = ['get_session']
