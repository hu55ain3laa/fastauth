from fastauth.dependencies.auth import AuthDependencies

__all__ = ['AuthDependencies']
